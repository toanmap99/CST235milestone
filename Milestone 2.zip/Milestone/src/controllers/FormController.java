package controllers;

/*
 * Brian Basinger
 * Toan Nguyen
 * Professor: Jevon Jackson
 * CST-235
 * 2/14/2021
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import beans.User;
import beans.Users;

//the controller to communicate with our model and our web content
@ManagedBean
@ViewScoped
public class FormController {
	
	public String onSubmit(User user)
	{
		// Forward to TestResponse.xhtml View along with the User Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "LoginSuccess.xhtml";
	}
	
	public String onRegSubmit(Users users) throws IOException
	{	
		// Forward to TestResponse.xhtml View along with the User Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("users", users);
		return "ThankYou.xhtml";
	}
	
	public String onLogin()
	{
		// Return back to the JSF Login page or the TestForm page
		return "login.xhtml";
	}
	
	public String onRegister()
	{
		// Return back to the JSF Login page or the TestForm page
		return "register.xhtml";
	} 
}
	/*
	 * public void saveUserToFile(Users users) throws IOException { //Works in a
	 * regular java workspace, for some reason does not save to file in EE version.
	 * File textFile = new File("users.txt"); FileWriter fw = new
	 * FileWriter(textFile, true); PrintWriter pw = new PrintWriter(fw);
	 * 
	 * String saveUser = users.getUsername()+","+ users.getPassword()+"," +
	 * users.getFirstName()+","+ users.getLastName()+"," + users.getEmail()+","+
	 * users.getMobilePhone()+"," +users.getCity()+","+users.getAddress()+","
	 * +users.getState()+","+users.getZip(); System.out.println(saveUser);
	 * pw.println(saveUser); pw.close(); fw.close(); }
	 */
	

