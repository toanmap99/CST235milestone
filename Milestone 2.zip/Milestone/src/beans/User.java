package beans;

/*
 * Brian Basinger
 * Toan Nguyen
 * Professor: Jevon Jackson
 * CST-235
 * 2/14/2021
 */

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/*
 * The user model for login.
 */
@ManagedBean
@ViewScoped
public class User 
{
	//properties
	@NotNull(message = "Please enter your username. This is REQUIRED!!")
	@Size(min=2, max=20)
	String username = "";
	
	@NotNull(message = "Please enter your password. This is REQUIRED!!")
	@Size(min=6, max=20, message="Size must be between 6-20 characters for passwords")
	String password = "";

	//constructor
	public User() {
		username = "tnguyen99";
		password = "123456789";
	}

	//getters and setters
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	

}
