package beans;

/*
 * Brian Basinger
 * Toan Nguyen
 * Professor: Jevon Jackson
 * CST-235
 * 3/6/2021
 */
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

/*
 * The users model for registration.
 */
@ManagedBean
@ViewScoped
public class Users {
	
	// Properties for the Users class
	
	@NotBlank(message = "Please enter a First Name. This is REQUIRED!!")
	@Size(min=2, max=20)
	String firstName = "";
	
	@NotBlank(message = "Please enter a Last Name. This is REQUIRED!!")
	@Size(min=2, max=20)
	String lastName = "";
	
	@NotBlank(message = "Please enter your username. This is REQUIRED!!")
	@Size(min=2, max=20)
	String username = "";
	
	@NotBlank(message = "Please enter your password. This is REQUIRED!!")
	@Size(min=6, max=20, message="Size must be between 6-20 characters for passwords")
	String password = "";
	
	@Email
	@NotBlank(message= "Please enter an email.")
	String email = "";
	
	@NotBlank(message = "Please enter your phone. This is REQUIRED!!")
	String mobilePhone = "";
	
	@NotBlank(message = "Please enter your address. This is REQUIRED!!")
	String address = "";
	
	@NotBlank(message = "Please enter your city. This is REQUIRED!!")
	String city = "";
	
	@NotBlank(message = "Please enter your state. This is REQUIRED!!")
	String state = "";
	
	@NotNull(message = "Please enter your zip code. This is REQUIRED!!")
	int zip = 0;
	
	// Default value in the constructors
	public Users() {
		this.firstName = "";
		this.lastName = "";
		this.username = "tnguyen99";
		this.password = "123456789";
		this.email = "dummy@yahoo.com";
		this.mobilePhone = "2225792587";
		this.address = "3300 W Camelback Road";
		this.city = "Phoenix";
		this.state = "AZ";
		this.zip = 85017;
	}
	
	//getters and setters
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	
	
	
	
}
