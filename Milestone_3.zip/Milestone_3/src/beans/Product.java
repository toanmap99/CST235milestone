/*
 * Brian Basinger
 * Toan Nguyen
 * Professor: Jevon Jackson
 * CST-235
 * 3/6/2021
 */
package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ManagedBean
@ViewScoped
public class Product {

	//properties
	@NotNull(message = "Enter your Product name.")
	@Size(min=2, max=20, message="Size must be between 2-20 characters for passwords")
	String productName = "";
		
	@NotNull(message = "Enter your description.")
	@Size(min=2, max=100, message="Size must be between 2-20 characters for passwords")
	String productDescription = "";
	
	@NotNull(message = "Enter your product price.")
	float price = 0;
		
	public Product() {
		productName = "Window 10";
		productDescription = "Microsoft's latest OS";
		price = 60;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	
	

}
