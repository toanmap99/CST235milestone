/*
 * Brian Basinger
 * Toan Nguyen
 * Professor: Jevon Jackson
 * CST-235
 * 3/6/2021
 */
package business;

import javax.ejb.Local;

/**
 * @author TOANSUPERBOSS
 *
 */

@Local
public interface ServiceInterface {

	public void testLogin();
	public void testRegister();
	public void testProduct();
}
