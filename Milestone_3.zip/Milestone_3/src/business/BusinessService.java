/*
 * Brian Basinger
 * Toan Nguyen
 * Professor: Jevon Jackson
 * CST-235
 * 3/6/2021
 */
package business;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

/**
 * Session Bean implementation class BusinessService
 */
@Stateless
@Local(ServiceInterface.class)
@LocalBean
@Alternative
public class BusinessService implements ServiceInterface {

	
    /**
     * Default constructor. 
     */
    public BusinessService() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServiceInterface#test()
     */
    public void testLogin() {
    	System.out.println("Login EJB Injected!!!!!");
    }
    
    public void testProduct() {
    	System.out.println("Product EJB Injected!!!!!");
    }
    public void testRegister() {
    	System.out.println("Register EJB Injected!!!!!");
    }

}
