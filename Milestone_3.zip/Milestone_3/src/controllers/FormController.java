package controllers;

/*
 * Brian Basinger
 * Toan Nguyen
 * Professor: Jevon Jackson
 * CST-235
 * 3/6/2021
 */


import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Product;
import beans.User;
import beans.Users;
import business.ServiceInterface;


//the controller to communicate with our model and our web content
@ManagedBean
@ViewScoped
public class FormController {
	
	@Inject
	ServiceInterface service;
	
	public String onSubmit(User user)
	{
		// Inject EJB
		service.testLogin();
		
		// Forward to TestResponse.xhtml View along with the User Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "LoginSuccess.xhtml";
	}
	
	public String onRegSubmit(Users users) 
	{	
		// Inject EJB
		service.testRegister();
				
		// Forward to TestResponse.xhtml View along with the User Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("users", users);
		return "ThankYou.xhtml";
	}
	
	public String onProductSubmit(Product product)
	{
		// Inject EJB
		service.testProduct();
		
		// Forward to ProductSuccess.xhtml
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("product", product);
		return "ProductSuccess.xhtml";
	}
	
	public String onProduct()
	{
		// Return back to the JSF Product registration page
		return "ProductRegister.xhtml";
	}
	public String onLogin()
	{
		// Return back to the JSF Login page or the TestForm page
		return "login.xhtml";
	}
	
	public String onRegister()
	{
		// Return back to the JSF Login page or the TestForm page
		return "register.xhtml";
	} 
	
	// Get service from the interface
	public ServiceInterface getService()
	{
		return service;
	}
}


